// Print JS

"use strict";
function myFunction() {
  window.print();
}
